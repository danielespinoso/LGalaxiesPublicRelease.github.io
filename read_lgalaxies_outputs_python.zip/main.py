# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 13:08:51 2023

@author: Rob Yates
"""

"""
main.py
  ;Main script when analysing L-Galaxies 2020 models.
  ;It calls reads-in the binaries, selects a "well-resolved" galaxies sample,
  ;saves thats sample to an .npy file, creates a dictionary containing that sample
  ;and L-Galaxies ring and SFH properties, and saves that dictionary to a .json file.
"""

#################
#Basic packages:
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import astropy
from astropy.io import fits
import json

#Local packages
from read_lgals_outputs import read_lgals_outputs
from make_lgals_sample import make_lgals_sample
from make_lgals_dictionary import make_lgals_dictionary


#################
#Switches:
SIMULATION  = 'MR' #Choose from: 'MR', 'MRII' 
FILE_TYPE = 'snapshots' #Choose from: 'snapshots', 'galtree'
MODEL = 'modified' #Choose from: 'default', 'modified' (see Yates+21a)
REDSHIFTS = [0.0]
FIRSTFILE = 5
LASTFILE = 5


#################
#Cosmological & resolution parameters:
TreeFilesUsed = LASTFILE-FIRSTFILE+1
TotTreeFiles = 512
Hubble_h      = 0.673
Omega_M       = 0.315 
Omega_Lambda  = 0.683
ParticleMassRes = 20. #Minimum number of DM particles per halo. #N.B. DMParticleMass*150. = 1.14e11 Msun/h (for Mil-I) or 1.16e9 Msun/h (for Mil-II), which is the advised minimum virial mass for "well-resolved" subhaloes.
if SIMULATION == 'MR' :  
    snap_z0 = 58
    BoxSideLength = 500.*0.960558 #Mpc/h
    DMParticleMass = 0.0961104*1e10 #Msun/h 
    StellarMassRes = 1.e9 #Rough recommended minimum stellar mass for well-resolved galaxies for Millennium
elif SIMULATION == 'MRII' : 
    snap_z0 = 62
    BoxSideLength = 100.*0.960558 #Mpc/h
    DMParticleMass = 0.000768884*1e10 #Msun/h
    StellarMassRes = 5.e7 #Rough recommended minimum stellar mass for well-resolved galaxies for Milennium-II
Volume = (BoxSideLength**3.0) * TreeFilesUsed / TotTreeFiles #(Mpc/h)^3 #Note, this volume needs to be divided by Hubble_h**3 to get the cosmology-dependent value in Mpc^3
char_z_low = "%0.2f" % REDSHIFTS[0]
char_z_high = "%0.2f" % REDSHIFTS[-1]
char_firstfile = "%0.2f" % FIRSTFILE
char_lastfile = "%0.2f" % LASTFILE
   
 
#################
#Read L-Galaxies outputs:
print('\n***************') 
print('L-GALAXIES 2020')
print('***************')  
print('Output info: '+SIMULATION+"_"+FILE_TYPE+"_"+MODEL+"_"+'z'+char_z_low+"-"+char_z_high+"_"+'F'+str(FIRSTFILE)+'-'+str(LASTFILE)) 
G_lgal, SFH_bins = read_lgals_outputs(Hubble_h, SIMULATION, FILE_TYPE, MODEL, FIRSTFILE, LASTFILE, REDSHIFTS)


#################                                                            
#Make sample of galaxies above the nominal resolution limit:       
G_samp = make_lgals_sample(G_lgal, FILE_TYPE, Hubble_h, DMParticleMass, ParticleMassRes, StellarMassRes, REDSHIFTS)
NumGals = len(G_samp) #Number of galaxies in the sample selected by make_lgals_sample.py (not the total number of objects in the treefiles used).
print('Sample made\n')


#################     
#Calculate ring info:
RNUM = 12
RBINS = 20 #Max number of SFH bins allowed in L-Galaxies.
RingArray = np.arange(1,RNUM+1)
RingRadii = 0.01*np.power(2.,RingArray)/Hubble_h #in kpc
RingArea = np.empty(RNUM) #in kpc^2
RingCenRadii = np.empty(RNUM)
#Calculate standard ring areas and central radii:
for ii in range(RNUM) :
    if ii == 0 :
        RingArea[ii] = np.pi * RingRadii[ii]**2
        RingCenRadii[ii] = 0.75*RingRadii[ii]
    else :
        RingArea[ii] = np.pi * (RingRadii[ii]**2 - RingRadii[ii-1]**2)
        RingCenRadii[ii] = RingRadii[ii-1] + ((RingRadii[ii] - RingRadii[ii-1])/2.)      


#################
#Calculate SFH properties:
if FILE_TYPE == 'snapshots' :
    theSnap = G_samp['SnapNum'][0] #The snapshot number corresponding to this snapshot file
elif FILE_TYPE == 'galtree' :
    theSnap = snap_z0
SFH_bins_lbt = SFH_bins.LOOKBACKTIME[SFH_bins.SNAPNUM == theSnap]/1.e9 #Gyr #Lookback times from z=0 to centre of each z=theSnap SFH bin
SFH_bins_dt = SFH_bins.DT[SFH_bins.SNAPNUM == theSnap] #yr #Width of bins from the z=theSnap SFH
SFH_bins_num = SFH_bins.BIN[SFH_bins.SNAPNUM == theSnap][-1] #Number of bins active in the z=theSnap SFH
SFH_bins_lbt_allGals = np.empty([NumGals,RNUM,RBINS])
SFH_bins_lbt_allGals[:] = np.nan
for ii in range(NumGals) :
    for jj in range(RNUM) :
        SFH_bins_lbt_allGals[ii][jj][0:SFH_bins_num] = SFH_bins_lbt
     
        
#################
#Make dictionary and save as a pickled .npy file:
Samp = make_lgals_dictionary(G_samp, SIMULATION, FILE_TYPE, MODEL, \
                                  NumGals, char_z_low, char_z_high, \
                                  RNUM, RingRadii, RingArea, \
                                  SFH_bins_num, SFH_bins_lbt_allGals)
np.save(SIMULATION+"_"+FILE_TYPE+"_"+MODEL+"_"+'z'+char_z_low+"-"+char_z_high+"_"+'F'+str(FIRSTFILE)+'-'+str(LASTFILE), Samp, allow_pickle=True)
##To load this pickled sample later on:
#Samp = np.load(SIMULATION+"_"+FILE_TYPE+"_"+MODEL+"_"+'z'+char_z_low+"-"+char_z_high+"_"+'Files'+FIRSTFILE+'-'+LASTFILE+".npy")

print("DONE!")

