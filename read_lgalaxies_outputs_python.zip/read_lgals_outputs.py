# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 13:31:18 2023

@author: Rob Yates
"""

"""
read_lgals_outputs.py
  ;Script to read-in L-Galaxies binary outputs.
  ;Also reads-in SFH bin info.
  ;Calls the read_snap() or read_tree() functions in procedures.py.
"""

#################
#Base packages:
import numpy as np
from importlib import reload
import astropy
from astropy.io import fits

#Local packages
import procedures
reload (procedures)
from procedures import read_snap, read_tree

#################
def read_lgals_outputs(Hubble_h, SIMULATION, FILE_TYPE, MODEL, FIRSTFILE, LASTFILE, REDSHIFTS) :         
    if MODEL == 'default' : 
        model_suffix = 'defaultModel'
    elif MODEL == 'modified' : 
        model_suffix = 'modifiedModel'
    else : print("***** ERROR: Model unknown. Please choose from: default, modified *****")    
    print('\n-------------')
    
    if FILE_TYPE == 'snapshots' :
        from LGalaxy_snapshots import LGalaxiesStruct
        from LGalaxy_snapshots import properties_used
        (G_lgal, SnapshotList) = read_snap(FIRSTFILE, LASTFILE, properties_used, LGalaxiesStruct, REDSHIFTS, model_suffix)

    elif FILE_TYPE == 'galtree' :  #<--WARNING: Untested! (26-01-23) 
        from LGalaxy_galtree import LGalaxiesStruct
        from LGalaxy_galtree import properties_used  
        (G_lgal) = read_tree(FIRSTFILE, LASTFILE, properties_used, LGalaxiesStruct, model_suffix) 
        SnapshotList = np.zeros(len(REDSHIFTS),dtype=np.int32)
        for ii in range(0,len(REDSHIFTS)):                  
            G0=G_lgal[ np.rint(G_lgal['Redshift']*100.) == REDSHIFTS[ii]*100. ]             
            SnapshotList[ii]=G0['SnapNum'][0]
    else : print("***** ERROR: File type unknown. Please choose from: snapshots, galtree *****")
    
    print('\nOutput read')
       
    #################
    #Read-in SFH bin info:
    SFH_bins = astropy.io.fits.open('Database_SFH_table.fits')
    SFH_bins = SFH_bins[1].data
    
    print('SFH bins read')
    print('-------------\n')
    
    return G_lgal, SFH_bins
    