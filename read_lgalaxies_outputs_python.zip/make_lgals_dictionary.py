# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 14:31:18 2023

@author: Rob Yates
"""

"""
make_lgals_dictionary.py
  ;Makes dictionary for the output data plus rings & SFH properties
"""

def make_lgals_dictionary(G_samp, SIMULATION, FILE_TYPE, MODEL, \
                          NumGals, char_lower_redshift, char_upper_redshift, \
                          RNUM, RingRadii, RingArea, \
                          SFH_bins_num, SFH_bins_lbt_allGals) : 
    Samp = {
            "G_samp": G_samp,
            "Simulation": SIMULATION,
            "File_type" : FILE_TYPE,
            "Model" : MODEL,
            "NumGals" : NumGals,
            "z_lower" : char_lower_redshift,
            "z_upper" : char_upper_redshift,
            "RNUM" : RNUM,
            "RingRadii" : RingRadii,
            "RingArea" : RingArea,
            "SFH_bins_num" : SFH_bins_num,
            "SFH_bins_lbt_allGals" : SFH_bins_lbt_allGals,
            }
    return Samp
