# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 14:10:52 2023

@author: Rob Yates
"""

"""
make_lgals_sample.py
  ;Script to make a sample of galaxies from the read-in output data
"""
import numpy as np

def make_lgals_sample(G_lgal, FILE_TYPE, Hubble_h, DMParticleMass, ParticleMassRes, StellarMassRes, REDSHIFTS) : 
    if FILE_TYPE == 'snapshots' : 
        G_samp = G_lgal[(G_lgal['Mvir']*1.e10 >= DMParticleMass*ParticleMassRes) \
                      & ((G_lgal['StellarMass']*1.e10)/Hubble_h >= StellarMassRes)]
    elif FILE_TYPE == 'galtree' :
        #Not tested yet! (26-01-23)
        yy = 0.0
    else : print("***** ERROR: File type not chosen. Please enter either 'snapshots' or 'galtree' for FILE_TYPE *****") 
    print('Number of galaxies selected: ', len(G_samp), '\n')
    
    return G_samp
